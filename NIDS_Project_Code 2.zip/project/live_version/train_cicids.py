"""Train the live-capable model on CICIDS2017 (MachineLearningCSV folder you download yourself).

Usage:  python train_cicids.py --data path/to/MachineLearningCSV
Classes: Normal, DoS (all DoS + DDoS), PortScan, Brute Force (FTP/SSH-Patator). Other attack types are dropped.
"""
import argparse, glob, json
from pathlib import Path
import joblib, numpy as np, pandas as pd
from sklearn.metrics import classification_report, confusion_matrix
from sklearn.model_selection import train_test_split
from xgboost import XGBClassifier
from cic_features import FEATURES

CLASSES = ["Normal", "DoS", "PortScan", "Brute Force"]
LABELS = {"BENIGN": "Normal", "DoS Hulk": "DoS", "DoS GoldenEye": "DoS", "DoS slowloris": "DoS", "DoS Slowhttptest": "DoS",
          "DDoS": "DoS", "PortScan": "PortScan", "FTP-Patator": "Brute Force", "SSH-Patator": "Brute Force"}
KEEP_FRAC = {"Normal": 0.08, "DoS": 0.25, "PortScan": 0.25, "Brute Force": 1.0}   # keeps memory low on a laptop

ap = argparse.ArgumentParser(); ap.add_argument("--data", required=True); ap.add_argument("--per-class", type=int, default=40000)
a = ap.parse_args(); here = Path(__file__).parent; rng = np.random.RandomState(42)
files = sorted(glob.glob(str(Path(a.data) / "*.csv")))
if not files: raise SystemExit(f"No CSV files found in {a.data}")
parts = []
for f in files:
    for ch in pd.read_csv(f, chunksize=200_000, skipinitialspace=True, low_memory=False):
        ch.columns = [c.strip() for c in ch.columns]
        miss = [c for c in FEATURES + ["Label"] if c not in ch.columns]
        if miss: raise SystemExit(f"{Path(f).name}: missing columns {miss[:5]} ... check you used the MachineLearningCSV files")
        ch["cls"] = ch["Label"].astype(str).str.strip().map(LABELS)
        ch = ch.dropna(subset=["cls"])
        ch = pd.concat([g.sample(frac=KEEP_FRAC[k], random_state=1) for k, g in ch.groupby("cls")])
        x = ch[FEATURES].apply(pd.to_numeric, errors="coerce").replace([np.inf, -np.inf], np.nan).astype("float32")
        x["cls"] = ch["cls"].values; parts.append(x)
    print("read", Path(f).name)
df = pd.concat(parts, ignore_index=True)
df = pd.concat([g.sample(n=min(len(g), a.per_class), random_state=2) for _, g in df.groupby("cls")])
print(df["cls"].value_counts().to_string())
X, y = df[FEATURES], df["cls"].map({c: i for i, c in enumerate(CLASSES)}).values
Xtr, Xte, ytr, yte = train_test_split(X, y, test_size=0.2, stratify=y, random_state=42)
w = len(ytr) / (len(CLASSES) * np.bincount(ytr, minlength=len(CLASSES)).clip(1))
m = XGBClassifier(n_estimators=300, max_depth=6, learning_rate=0.1, tree_method="hist", n_jobs=-1, random_state=42)
m.fit(Xtr, ytr, sample_weight=w[ytr])
pred = m.predict(Xte)
print(classification_report(yte, pred, target_names=CLASSES, zero_division=0))
cm = confusion_matrix(yte, pred, labels=range(len(CLASSES))); print(cm)
fpr = float(np.mean(pred[yte == 0] != 0)); print(f"False positive rate (Normal flagged as attack): {fpr:.4f}")
(here / "models").mkdir(exist_ok=True)
joblib.dump(dict(model=m, classes=CLASSES, features=FEATURES), here / "models/cicids_xgb.pkl")
json.dump(dict(false_positive_rate=fpr, confusion_matrix=cm.tolist(), classes=CLASSES), open(here / "models/cicids_metrics.json", "w"), indent=2)
print("Saved models/cicids_xgb.pkl")
