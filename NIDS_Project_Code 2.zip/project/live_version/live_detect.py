"""Live network intrusion detection: capture packets -> flows (CICFlowMeter features) -> model -> alerts.

Only capture on your own network or one you are authorised to monitor.
  python live_detect.py --list-ifaces
  python live_detect.py --iface "Wi-Fi"           # run the terminal as Administrator (Windows) or with sudo (Linux/macOS)
  python live_detect.py --pcap sample.pcap        # same pipeline on a saved capture (no admin rights needed)
Windows also needs Npcap (https://npcap.com) installed.
"""
import argparse, csv, queue, threading, time
from datetime import datetime
from pathlib import Path
import joblib, numpy as np
from scapy.all import AsyncSniffer, PcapReader, get_if_list
import cicflowmeter.flow_session as fs
from cicflowmeter.flow_session import FlowSession
from cic_features import flows_to_frame

fs.EXPIRED_UPDATE = 20          # report idle flows after 20 s (library default is 240 s, far too slow for live alerts)
HERE = Path(__file__).parent
SEV = {"DoS": "High", "Brute Force": "High", "PortScan": "Medium"}

ap = argparse.ArgumentParser()
ap.add_argument("--iface"); ap.add_argument("--pcap"); ap.add_argument("--list-ifaces", action="store_true")
ap.add_argument("--model", default=str(HERE / "models/cicids_xgb.pkl")); ap.add_argument("--min-conf", type=float, default=0.7)
ap.add_argument("--log", default=str(HERE / "logs/live_alerts.csv"))
a = ap.parse_args()
if a.list_ifaces:
    print("\n".join(get_if_list())); raise SystemExit
if bool(a.iface) == bool(a.pcap): raise SystemExit("Give exactly one of --iface or --pcap (or --list-ifaces).")

bundle = joblib.load(a.model); model, CLASSES, FEATURES = bundle["model"], bundle["classes"], bundle["features"]
q = queue.Queue()
class QueueWriter:                      # receives each finished flow from the flow extractor
    def write(self, d): q.put(d)
session = FlowSession(output_mode="csv", output="/dev/null" if Path("/dev/null").exists() else "NUL")
session.output_writer = QueueWriter()

def feed(pkt):                          # filter in Python so no libpcap filter compiler is needed
    if pkt.haslayer("IP") and (pkt.haslayer("TCP") or pkt.haslayer("UDP")): session.process(pkt)

Path(a.log).parent.mkdir(exist_ok=True)
logf = open(a.log, "w", newline=""); lw = csv.writer(logf)
lw.writerow(["time", "src", "dst", "dst_port", "protocol", "predicted", "risk", "confidence"])
total = attacks = 0

def handle(batch):
    global total, attacks
    X = flows_to_frame(batch)[FEATURES]
    proba = model.predict_proba(X); idx = proba.argmax(1); conf = proba.max(1)
    for f, i, c in zip(batch, idx, conf):
        total += 1
        cls = CLASSES[i]
        if cls == "Normal" or c < a.min_conf: continue
        attacks += 1; risk = SEV.get(cls, "Medium") if c >= 0.85 else "Low"
        t = datetime.now().strftime("%H:%M:%S")
        print(f"[{t}] ALERT {cls:12s} risk={risk:6s} conf={c:.2f}  {f['src_ip']}:{f['src_port']} -> {f['dst_ip']}:{f['dst_port']}")
        lw.writerow([t, f["src_ip"], f["dst_ip"], f["dst_port"], f["protocol"], cls, risk, round(float(c), 3)]); logf.flush()

def drain():
    batch = []
    while True:
        try: batch.append(q.get_nowait())
        except queue.Empty: break
    if batch: handle(batch)

if a.pcap:
    for p in PcapReader(a.pcap): feed(p)
    session.garbage_collect(None); drain()
else:
    stop = threading.Event()
    def gc():
        while not stop.wait(1.0): session.garbage_collect(time.time())
    threading.Thread(target=gc, daemon=True).start()
    sn = AsyncSniffer(iface=a.iface, prn=feed, store=False); sn.start()
    print(f"Listening on {a.iface}. Press Ctrl+C to stop.")
    try:
        while True: time.sleep(1); drain()
    except KeyboardInterrupt:
        pass
    finally:
        sn.stop(); stop.set(); session.garbage_collect(None); drain()
print(f"Flows analysed: {total} | alerts: {attacks} | log: {a.log}")
logf.close()
