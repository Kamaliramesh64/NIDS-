# Live version: capture real traffic and detect attacks

The main project replays NSL-KDD records. This folder captures packets from a network interface, turns them into
flows with the same features as the CICIDS2017 dataset, and classifies each flow (Normal, DoS, PortScan, Brute Force).

## Steps
1. Download CICIDS2017 "MachineLearningCSV" (CSV files, about 225 MB zip) from the Canadian Institute for Cybersecurity
   (UNB) website and unzip it. Training uses a sample, so 8 GB RAM is enough.
2. `pip install -r requirements.txt`
3. Train:  `python train_cicids.py --data path/to/MachineLearningCSV`   (prints a report and saves models/cicids_xgb.pkl)
4. Windows only: install Npcap (https://npcap.com), then open the terminal as Administrator. Linux/macOS: use sudo.
5. `python live_detect.py --list-ifaces`  then  `python live_detect.py --iface "<name>"`
   Without admin rights, test the same pipeline on a saved capture:  `python live_detect.py --pcap file.pcap`
6. Alerts print in the terminal and are saved to logs/live_alerts.csv. Press Ctrl+C to stop.

## Important limits
- Capture only on your own network or one you are authorised to monitor.
- Flows are reported after they end (FIN) or after 20 seconds idle, so alerts are not instant.
- CICIDS2017 was recorded in a lab. Ordinary traffic on another network can be flagged by mistake, so expect false alarms
  and report the measured false positive rate honestly.
- Time features: the original CICFlowMeter writes microseconds, the Python port writes seconds. cic_features.py converts
  them (x 1e6). If results look wrong, check this first.
- The code was tested here only on synthetic traffic and loopback capture, not on the real CICIDS2017 files.
