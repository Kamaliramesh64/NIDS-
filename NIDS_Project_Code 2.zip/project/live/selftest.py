"""Checks the flow extractor on a few hand-made packets (no model or dataset needed).  Run: python live/selftest.py"""
import sys, tempfile, os
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent))
from scapy.all import Ether, IP, TCP, UDP, Raw, wrpcap, PcapReader
from flow_features import FlowTable, FEATURES

def pk(t, layer):
    p = Ether() / layer; p.time = t; return p

c, s = "10.0.0.1", "10.0.0.2"
pkts = [
    pk(0.000, IP(src=c, dst=s) / TCP(sport=40000, dport=80, flags="S", window=8192)),
    pk(0.001, IP(src=s, dst=c) / TCP(sport=80, dport=40000, flags="SA", window=29200)),
    pk(0.002, IP(src=c, dst=s) / TCP(sport=40000, dport=80, flags="A", window=8192)),
    pk(0.003, IP(src=c, dst=s) / TCP(sport=40000, dport=80, flags="PA", window=8192) / Raw(b"x" * 100)),
    pk(0.004, IP(src=s, dst=c) / TCP(sport=80, dport=40000, flags="A", window=29200)),
    pk(0.005, IP(src=s, dst=c) / TCP(sport=80, dport=40000, flags="PA", window=29200) / Raw(b"y" * 500)),
    pk(0.006, IP(src=c, dst=s) / TCP(sport=40000, dport=80, flags="FA", window=8192)),
    pk(0.007, IP(src=s, dst=c) / TCP(sport=80, dport=40000, flags="A", window=29200)),      # trailing ACK, must be ignored
    pk(1.000, IP(src="10.0.0.9", dst=s) / TCP(sport=5555, dport=22, flags="S")),             # lone SYN (scan-like)
    pk(1.001, IP(src="10.0.0.5", dst=s) / UDP(sport=5353, dport=53) / Raw(b"q" * 30)),
    pk(1.002, IP(src=s, dst="10.0.0.5") / UDP(sport=53, dport=5353) / Raw(b"r" * 60)),
]
path = os.path.join(tempfile.mkdtemp(), "t.pcap"); wrpcap(path, pkts)
out = []
table = FlowTable(on_flow=out.append, idle=5)
for p in PcapReader(path):
    table.add_packet(p, float(p.time))
table.flush()
assert len(out) == 3, f"expected 3 flows, got {len(out)}"
f = {(x.dport): dict(zip(FEATURES, x.features())) for x in out}
a = f[80]
checks = [("Total Fwd Packets", 4), ("Total Backward Packets", 3), ("Total Length of Fwd Packets", 100),
          ("Total Length of Bwd Packets", 500), ("Flow Duration", 6000), ("SYN Flag Count", 2), ("FIN Flag Count", 1),
          ("PSH Flag Count", 2), ("Fwd PSH Flags", 1), ("Init_Win_bytes_forward", 8192), ("Init_Win_bytes_backward", 29200),
          ("act_data_pkt_fwd", 1), ("Fwd Packet Length Max", 100), ("Bwd Packet Length Max", 500), ("Down/Up Ratio", 0),
          ("Fwd Header Length", 4 * 20 + 4 * 20), ("Fwd IAT Total", 6000)]
for name, want in checks:
    got = a[name]
    assert abs(got - want) < 1e-6, f"{name}: expected {want}, got {got}"
assert f[22]["Total Fwd Packets"] == 1 and f[22]["Flow Duration"] == 0 and f[22]["Flow Packets/s"] == 0
assert f[53]["Total Length of Fwd Packets"] == 30 and f[53]["Total Length of Bwd Packets"] == 60
print(f"OK: {len(out)} flows, {len(FEATURES)} features, {len(checks)+4} checks passed")
