"""Turn raw packets (Scapy) into bidirectional flows and CICIDS2017-style flow features.

The feature names match the columns of the CICIDS2017 "MachineLearningCSV" files, so a model trained
on those CSVs can score flows built here. Definitions follow CICFlowMeter (payload-based lengths,
IAT in microseconds, flow ends on FIN or timeout). Small differences from the original tool are
possible, so see README_LIVE.md before trusting live scores.
"""
import numpy as np
from scapy.layers.inet import IP, TCP, UDP
from scapy.layers.inet6 import IPv6

# Destination Port is left out on purpose: it lets a model memorise the dataset's attacker ports.
FEATURES = [
    "Flow Duration", "Total Fwd Packets", "Total Backward Packets",
    "Total Length of Fwd Packets", "Total Length of Bwd Packets",
    "Fwd Packet Length Max", "Fwd Packet Length Min", "Fwd Packet Length Mean", "Fwd Packet Length Std",
    "Bwd Packet Length Max", "Bwd Packet Length Min", "Bwd Packet Length Mean", "Bwd Packet Length Std",
    "Flow Bytes/s", "Flow Packets/s",
    "Flow IAT Mean", "Flow IAT Std", "Flow IAT Max", "Flow IAT Min",
    "Fwd IAT Total", "Fwd IAT Mean", "Fwd IAT Std", "Fwd IAT Max", "Fwd IAT Min",
    "Bwd IAT Total", "Bwd IAT Mean", "Bwd IAT Std", "Bwd IAT Max", "Bwd IAT Min",
    "Fwd PSH Flags", "Fwd Header Length", "Bwd Header Length", "Fwd Packets/s", "Bwd Packets/s",
    "Min Packet Length", "Max Packet Length", "Packet Length Mean", "Packet Length Std", "Packet Length Variance",
    "FIN Flag Count", "SYN Flag Count", "RST Flag Count", "PSH Flag Count", "ACK Flag Count", "URG Flag Count",
    "Down/Up Ratio", "Init_Win_bytes_forward", "Init_Win_bytes_backward", "act_data_pkt_fwd",
]
FIN, SYN, RST, PSH, ACK, URG = 0x01, 0x02, 0x04, 0x08, 0x10, 0x20


def _stats(a):
    """max, min, mean, sample std (n-1, like CICFlowMeter's Commons-Math); zeros when empty."""
    if len(a) == 0:
        return 0.0, 0.0, 0.0, 0.0
    a = np.asarray(a, dtype=float)
    return float(a.max()), float(a.min()), float(a.mean()), float(a.std(ddof=1)) if len(a) > 1 else 0.0


class Flow:
    def __init__(self, ts, src, sport, dst, dport, proto):
        self.src, self.sport, self.dst, self.dport, self.proto = src, sport, dst, dport, proto
        self.start = self.last = ts
        self.ts_all, self.fts, self.bts = [], [], []
        self.flen, self.blen = [], []
        self.fhdr = self.bhdr = 0
        self.fin = self.syn = self.rst = self.psh = self.ack = self.urg = self.fpsh = 0
        self.init_f = self.init_b = -1
        self.act_f = 0

    def add(self, ts, fwd, payload, hdr, flags, win):
        self.last = ts
        self.ts_all.append(ts)
        if fwd:
            self.fts.append(ts); self.flen.append(payload); self.fhdr += hdr
            if payload > 0: self.act_f += 1
            if flags & PSH: self.fpsh += 1
            if self.init_f < 0 and win is not None: self.init_f = win
        else:
            self.bts.append(ts); self.blen.append(payload); self.bhdr += hdr
            if self.init_b < 0 and win is not None: self.init_b = win
        self.fin += bool(flags & FIN); self.syn += bool(flags & SYN); self.rst += bool(flags & RST)
        self.psh += bool(flags & PSH); self.ack += bool(flags & ACK); self.urg += bool(flags & URG)

    def features(self):
        dur_us = (self.last - self.start) * 1e6
        dur_s = dur_us / 1e6
        nf, nb = len(self.flen), len(self.blen)
        fmax, fmin, fmean, fstd = _stats(self.flen)
        bmax, bmin, bmean, bstd = _stats(self.blen)
        alll = self.flen + self.blen
        pmax, pmin, pmean, pstd = _stats(alll)
        iat = np.diff(self.ts_all) * 1e6 if len(self.ts_all) > 1 else []
        fiat = np.diff(self.fts) * 1e6 if len(self.fts) > 1 else []
        biat = np.diff(self.bts) * 1e6 if len(self.bts) > 1 else []
        imax, imin, imean, istd = _stats(iat)
        fimax, fimin, fimean, fistd = _stats(fiat)
        bimax, bimin, bimean, bistd = _stats(biat)
        tot_bytes = sum(alll)
        v = {
            "Flow Duration": dur_us, "Total Fwd Packets": nf, "Total Backward Packets": nb,
            "Total Length of Fwd Packets": sum(self.flen), "Total Length of Bwd Packets": sum(self.blen),
            "Fwd Packet Length Max": fmax, "Fwd Packet Length Min": fmin, "Fwd Packet Length Mean": fmean, "Fwd Packet Length Std": fstd,
            "Bwd Packet Length Max": bmax, "Bwd Packet Length Min": bmin, "Bwd Packet Length Mean": bmean, "Bwd Packet Length Std": bstd,
            "Flow Bytes/s": tot_bytes / dur_s if dur_s > 0 else 0.0,
            "Flow Packets/s": (nf + nb) / dur_s if dur_s > 0 else 0.0,
            "Flow IAT Mean": imean, "Flow IAT Std": istd, "Flow IAT Max": imax, "Flow IAT Min": imin,
            "Fwd IAT Total": float(np.sum(fiat)) if len(fiat) else 0.0, "Fwd IAT Mean": fimean, "Fwd IAT Std": fistd, "Fwd IAT Max": fimax, "Fwd IAT Min": fimin,
            "Bwd IAT Total": float(np.sum(biat)) if len(biat) else 0.0, "Bwd IAT Mean": bimean, "Bwd IAT Std": bistd, "Bwd IAT Max": bimax, "Bwd IAT Min": bimin,
            "Fwd PSH Flags": self.fpsh, "Fwd Header Length": self.fhdr, "Bwd Header Length": self.bhdr,
            "Fwd Packets/s": nf / dur_s if dur_s > 0 else 0.0, "Bwd Packets/s": nb / dur_s if dur_s > 0 else 0.0,
            "Min Packet Length": pmin, "Max Packet Length": pmax, "Packet Length Mean": pmean,
            "Packet Length Std": pstd, "Packet Length Variance": pstd ** 2,
            "FIN Flag Count": self.fin, "SYN Flag Count": self.syn, "RST Flag Count": self.rst,
            "PSH Flag Count": self.psh, "ACK Flag Count": self.ack, "URG Flag Count": self.urg,
            "Down/Up Ratio": int(nb / nf) if nf else 0,
            "Init_Win_bytes_forward": self.init_f, "Init_Win_bytes_backward": self.init_b, "act_data_pkt_fwd": self.act_f,
        }
        return [v[k] for k in FEATURES]


def parse_packet(pkt):
    """Return (src, sport, dst, dport, proto, payload, header_len, tcp_flags, window) or None."""
    if IP in pkt:
        ip = pkt[IP]; src, dst, ihl = ip.src, ip.dst, ip.ihl * 4
        l4len = ip.len - ihl if ip.len else None
    elif IPv6 in pkt:
        ip = pkt[IPv6]; src, dst, ihl = ip.src, ip.dst, 40
        l4len = ip.plen if ip.plen else None
    else:
        return None
    if TCP in pkt:
        t = pkt[TCP]; hl = t.dataofs * 4
        payload = max(0, l4len - hl) if l4len is not None else len(t.payload)
        return src, t.sport, dst, t.dport, "tcp", payload, ihl + hl, int(t.flags), int(t.window)
    if UDP in pkt:
        u = pkt[UDP]
        payload = max(0, (u.len or 8) - 8)
        return src, u.sport, dst, u.dport, "udp", payload, ihl + 8, 0, None
    return None


class FlowTable:
    """Groups packets into flows. A flow ends on FIN, after `idle` seconds of silence, or after `max_active` seconds."""

    def __init__(self, on_flow, idle=10.0, max_active=120.0):
        self.on_flow, self.idle, self.max_active = on_flow, idle, max_active
        self.flows, self.closed = {}, {}

    def add_packet(self, pkt, ts):
        p = parse_packet(pkt)
        if p is None:
            return
        src, sport, dst, dport, proto, payload, hdr, flags, win = p
        k1, k2 = (src, sport, dst, dport, proto), (dst, dport, src, sport, proto)
        if (k1 in self.closed or k2 in self.closed) and not (flags & SYN):
            if ts - self.closed.get(k1, self.closed.get(k2)) < 3.0:
                return                      # trailing ACK/FIN of a flow we already finished
        if k1 in self.flows:
            f, fwd, key = self.flows[k1], True, k1
        elif k2 in self.flows:
            f, fwd, key = self.flows[k2], False, k2
        else:
            f, fwd, key = Flow(ts, src, sport, dst, dport, proto), True, k1
            self.flows[k1] = f
            self.closed.pop(k1, None); self.closed.pop(k2, None)
        f.add(ts, fwd, payload, hdr, flags, win)
        if flags & FIN:
            self._finish(key, ts)

    def _finish(self, key, ts=None):
        f = self.flows.pop(key)
        if ts is not None:
            self.closed[key] = ts
        self.on_flow(f)

    def expire(self, now):
        for key in [k for k, f in self.flows.items() if now - f.last > self.idle or now - f.start > self.max_active]:
            self._finish(key)
        for k in [k for k, t in self.closed.items() if now - t > 3.0]:
            del self.closed[k]

    def flush(self):
        for key in list(self.flows):
            self._finish(key)
